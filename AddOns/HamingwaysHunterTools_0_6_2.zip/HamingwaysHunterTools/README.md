# AutoHunt (Vanilla 1.12)

Install
- Copy `AddOns/AutoHunt` into your `Interface/AddOns` folder for WoW Vanilla 1.12.

What it does
- Shows a small status bar with your ranged weapon Auto Shot cooldown.

Usage
- Drag the bar to move it; position is saved per character.
- Commands: `/autohunt reset` — reset timer, `/autohunt lock` — disable dragging, `/autohunt unlock` — enable dragging.

Notes for maintainers
- Saved variables: `SavedVariablesPerCharacter: AutoHuntDB` (stored fields: `point`, `x`, `y`).
- Key files: `AutoHunt.toc`, `AutoHunt.lua`.
- Detection: The addon listens to combat chat messages and matches simple keyword patterns; for higher reliability consider using the combat log API if available on target client.

License
- No license specified — treat as simple example code. Ask author to add license if needed.
