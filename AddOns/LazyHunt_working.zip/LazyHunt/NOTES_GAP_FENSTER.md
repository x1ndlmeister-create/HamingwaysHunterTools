# LazyHunt - Gap Fenster und Timing Informationen

## Datum: 2026-01-24

---

## State Machine Architektur

### Main Steps
- **STEP_INIT**: Initialisierung (HHT laden, Spells cachen, warten auf ersten Auto Shot)
- **STEP_WORK**: Hauptrotation

### Rotation Steps
- **ROTA_DO_NOTHING**: Idle, wartet auf Yellow Phase Entscheidung
- **ROTA_DO_STEADY**: Steady Shot casten
- **ROTA_DO_MULTI**: Multi-Shot casten  
- **ROTA_DO_MULTIAFTERSTEADY**: Nach Steady fertig, versuche Multi zu casten

---

## Rotation Flow

### Yellow Phase (Aiming Time)
1. TryBurst() einmal pro Yellow Phase
2. **Entscheidung** nur wenn `currentRotaStep == DO_NOTHING`:
   - Wenn `shouldCastMultiInsteadOfSteady == true` → DO_MULTI
   - Sonst → DO_STEADY
3. Wenn `currentRotaStep == DO_STEADY` oder `DO_MULTI` (Cast hat nicht gestartet):
   - Reset auf DO_NOTHING und steadyCastTime = 0
   - Neue Entscheidung treffen

### Red Phase (Nach Auto Shot feuert)
1. Reset `hasBurstedThisYellowPhase = false`
2. Check Auto Shot aktiv (lastShotTime > 0)
3. **Execution basierend auf currentRotaStep**:

#### DO_MULTI
- Weapon Cache update (für fit calculation)
- CanMultiFit() prüfen: `multiTotalTime < timeLeftInRed`
- Multi casten, zurück zu DO_NOTHING

#### DO_STEADY  
- Wenn `steadyCastTime > 0`: Springe zu MULTIAFTERSTEADY
- `CastSpellByName(Steady)`
- **IsCasting() prüfen** bevor Transition zu MULTIAFTERSTEADY
- Wenn Cast nicht startet: bleibt in DO_STEADY (wird in Yellow resettet)

#### DO_MULTIAFTERSTEADY
- Warte auf Steady finish: `(now - steadyCastTime) < steadyCastDuration + 0.2`
- Nach Steady fertig: Weapon Cache update
- **Prüfe: Passt Steady im nächsten Zyklus?**
  - `canSteadyFitNextCycle = (gcdRemainingAfterAutoShot + steadyCastDuration) < (nextRedPhaseDuration + allowedDelay)`
  
**Wenn canSteadyFitNextCycle == true:**
- `shouldCastMultiInsteadOfSteady = false` (IMMER setzen!)
- Versuche Multi zu casten (wenn enabled und CD ready)
- Nächster Zyklus: Steady wieder casten

**Wenn canSteadyFitNextCycle == false:**
- `shouldCastMultiInsteadOfSteady = true`
- Multi NICHT casten
- Nächster Zyklus: Multi statt Steady

---

## Gap Fenster und Timing Berechnungen

### Multi-Shot Fit Calculation
```lua
local multiGCD = 1.5
local multiCD = GetSpellCooldown(Multi)
if multiCD < 0 then multiCD = 0 end
local multiTotalTime = 1.5 + multiCD

-- Passt Multi in verbleibende Red Phase?
local timeLeftInRed = redPhaseEnd - elapsed
if multiTotalTime < timeLeftInRed then
    -- Multi casten
end
```

### Steady Fit Next Cycle Calculation
```lua
local multiGCD = 1.5  -- GCD von Multi
local yellowPhase = cachedAimingTime
local nextRedPhaseDuration = cachedWeaponSpeed - cachedAimingTime
local steadyCastDuration = 1.0 * (cachedWeaponSpeed / 2.0)

-- Wie viel GCD bleibt nach nächstem Auto Shot?
local gcdRemainingAfterAutoShot = multiGCD - (timeLeftInRed + yellowPhase)
if gcdRemainingAfterAutoShot < 0 then gcdRemainingAfterAutoShot = 0 end

-- Passt Steady (inkl. verbleibender GCD) in nächste Red Phase?
local allowedDelay = LazyHuntDB.allowedASDelay or 0.0
local canSteadyFitNextCycle = (gcdRemainingAfterAutoShot + steadyCastDuration) < (nextRedPhaseDuration + allowedDelay)
```

### Wichtige Timings
- **Multi-Shot Cast Time**: 0.5s
- **Multi-Shot GCD**: 1.5s
- **Steady Shot Cast Time**: `1.0 * (weaponSpeed / 2.0)`
- **Yellow Phase**: Aiming Time vom Bogen
- **Red Phase**: `weaponSpeed - aimingTime`
- **Allowed Auto Shot Delay**: Konfigurierbar in LazyHuntDB.allowedASDelay

---

## Bekannte Bugs (Stand 2026-01-24)

### ✅ GEFIXED
1. Yellow Phase überschreibt currentRotaStep jeden Frame
   - Fix: Nur Entscheidung wenn `currentRotaStep == DO_NOTHING`

2. Steady Casting Loop (bleibt in DO_STEADY hängen)
   - Fix: `IsCasting()` zu HHT API hinzugefügt
   - Cast-Verification vor Transition zu MULTIAFTERSTEADY

3. Nach Multi: Nächster Zyklus kein Steady
   - Fix: `shouldCastMultiInsteadOfSteady = false` IMMER setzen wenn canSteadyFitNextCycle true
   - Nicht nur wenn Multi gecastet wird

4. Zwischen 2 Autos kein Steady gecastet (teilweise)
   - Fix: Yellow Phase resettet DO_STEADY/DO_MULTI wenn Cast nicht gestartet
   - Problem noch nicht vollständig gelöst

### ❌ NOCH OFFEN
- Teilweise wird zwischen 2 Auto Shots kein Steady gecastet
- Weitere Debug-Ausgaben nötig um zu sehen wann/warum

---

## HamingwaysHunterTools API

### Hinzugefügt heute
```lua
HamingwaysHunterTools_API.IsCasting = function() return isCasting end
```

### Verfügbare Methoden
- `IsReloading()` - Reload aktiv?
- `IsShooting()` - Auto Shot aktiv?
- `IsCasting()` - Cast aktiv? (NEU)
- `GetLastShotTime()` - Zeitstempel letzter Auto Shot
- `GetWeaponSpeed()` - Aktuelle Weapon Speed
- `GetAimingTime()` - Aiming Time
- `IsInRedPhase()` - In Red Phase?
- `IsInYellowPhase()` - In Yellow Phase?
- `NotifyCast(spellName, castTime)` - Cast registrieren

---

## Offene Fragen für Morgen

1. Warum wird manchmal kein Steady gecastet zwischen 2 Autos?
   - Ist es ein Timing Problem?
   - Startet IsCasting() zu spät/nie?
   - Ist die Red Phase zu kurz?

2. Sollte es ein "Gap Fenster" geben wo keine Spells gecastet werden?
   - Mindestabstand zum nächsten Auto Shot?
   - Safety margin?

3. Debug Output erweitern:
   - IsCasting() Status loggen
   - Timing loggen (timeLeftInRed, steadyCastDuration, etc.)
   - Yellow/Red Phase transitions

---

## Code-Reduktion
- Ursprünglich: ~970 Zeilen
- Aktuell: ~610 Zeilen
- Entfernt: ~360 Zeilen (allowRedPhaseLogic, hasDecidedThisCycle, doppelte Checks, etc.)

---

## Nächste Schritte

1. **Debug erweitern** um herauszufinden warum manchmal kein Steady gecastet wird
2. **Gap Fenster Logik** implementieren (falls benötigt)
3. **Testing** der vollständigen Rotation über mehrere Auto Shots
4. **Debug Code entfernen** wenn alles funktioniert
5. **Performance testen** (Reaction Time ~0.015s?)
