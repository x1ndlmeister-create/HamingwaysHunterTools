-- LazyHunt - Hunter Rotation Addon for WoW Vanilla 1.12 (Turtle WoW)
-- Version: 3.2.0 - Flowchart implementation
-- Author: Copilot

local VERSION = "3.2.0"

-- Saved Variables
LazyHuntDB = LazyHuntDB or {}

-- Rotation state variables (per flowchart)
local debugMode = false
local lastAutoShotTime = 0
local castingSpell = nil  -- nil, "STEADY", or "MULTI" - what we're currently casting
local castStartTime = 0   -- When the current cast started
local useMultiInsteadOfSteady = false      -- Flag: Cast Multi instead of Steady next cycle
local shouldCastMultiAfterSteady = false   -- Flag: Cast Multi immediately after Steady finishes

-- Performance throttle
local lastUpdateTime = 0
local UPDATE_INTERVAL = 0.05

-- Cached values
local cachedWeaponSpeed = 2.0
local cachedAimingTime = 0.5
local lastWeaponCacheTime = 0
local WEAPON_CACHE_INTERVAL = 2.0

-- Cached spell IDs
local cachedSteadyID, cachedSteadyName = nil, nil
local cachedMultiID, cachedMultiName = nil, nil
local cachedRapidFireID = nil

-- Cache spell lookups
local function CacheSpellIDs()
    local i = 1
    while true do
        local name = GetSpellName(i, BOOKTYPE_SPELL)
        if not name then break end
        
        if (name == "Steady Shot" or name == "Stetiger Schuss") and not cachedSteadyID then
            cachedSteadyID = i
            cachedSteadyName = name
        elseif (name == "Multi-Shot" or name == "Mehrfachschuss") and not cachedMultiID then
            cachedMultiID = i
            cachedMultiName = name
        elseif name == "Rapid Fire" and not cachedRapidFireID then
            cachedRapidFireID = i
        end
        
        if cachedSteadyID and cachedMultiID and cachedRapidFireID then
            break
        end
        
        i = i + 1
    end
end

-- ============================================================================
-- BURST MODE
-- ============================================================================

local function GetSunderArmorStacks()
    local i = 1
    while UnitDebuff("target", i) do
        local texture = UnitDebuff("target", i)
        if texture and string.find(texture, "Ability_Warrior_Sunder") then
            return i
        end
        i = i + 1
    end
    return 0
end

local function ShouldBurst()
    if not LazyHuntDB.burstEnabled then
        return false
    end
    
    if not UnitAffectingCombat("player") then
        return false
    end
    
    if not UnitExists("target") or UnitIsDead("target") then
        return false
    end
    
    local requiredStacks = LazyHuntDB.burstSunderStacks or 0
    if requiredStacks > 0 then
        local stacks = GetSunderArmorStacks()
        if stacks < requiredStacks then
            return false
        end
    end
    
    return true
end

local function TryBurst()
    if not ShouldBurst() then
        return false
    end
    
    if castingSpell ~= nil then
        return false
    end
    
    local rapidFireReady = false
    local rapidFireCD = 999
    if cachedRapidFireID then
        local rapidFireStart, rapidFireDuration = GetSpellCooldown(cachedRapidFireID, BOOKTYPE_SPELL)
        rapidFireCD = (rapidFireStart > 0 and (rapidFireStart + rapidFireDuration - GetTime()) > 1.5) and (rapidFireStart + rapidFireDuration - GetTime()) or 0
        rapidFireReady = rapidFireCD == 0
    end
    
    local trinket13Ready = false
    local trinket13CD = 999
    local start13, duration13 = GetInventoryItemCooldown("player", 13)
    if start13 then
        trinket13CD = (start13 > 0 and (start13 + duration13 - GetTime()) > 1.5) and (start13 + duration13 - GetTime()) or 0
        trinket13Ready = trinket13CD == 0
    end
    
    local trinket14Ready = false
    local trinket14CD = 999
    local start14, duration14 = GetInventoryItemCooldown("player", 14)
    if start14 then
        trinket14CD = (start14 > 0 and (start14 + duration14 - GetTime()) > 1.5) and (start14 + duration14 - GetTime()) or 0
        trinket14Ready = trinket14CD == 0
    end
    
    if not rapidFireReady and not trinket13Ready and not trinket14Ready then
        return false
    end
    
    if LazyHuntDB.waitForBurstCD then
        local threshold = LazyHuntDB.burstCDThreshold or 5
        
        if rapidFireReady or trinket13Ready or trinket14Ready then
            local maxCD = 0
            if not rapidFireReady and rapidFireCD < 999 then
                maxCD = math.max(maxCD, rapidFireCD)
            end
            if not trinket13Ready and trinket13CD < 999 then
                maxCD = math.max(maxCD, trinket13CD)
            end
            if not trinket14Ready and trinket14CD < 999 then
                maxCD = math.max(maxCD, trinket14CD)
            end
            
            if maxCD > 0 and maxCD <= threshold then
                return false
            end
        end
    end
    
    if rapidFireReady then
        CastSpellByName("Rapid Fire")
    end
    
    if trinket13Ready then
        UseInventoryItem(13)
    end
    
    if trinket14Ready then
        UseInventoryItem(14)
    end
    
    if rapidFireReady then
        lastWeaponCacheTime = 0
    end
    
    return true
end

-- ============================================================================
-- FLOWCHART HELPER FUNCTIONS
-- ============================================================================

-- CanMultiFit: Check if Multi-Shot is available
local function CanMultiFit()
    if not LazyHuntDB.multiShotEnabled then
        return false
    end
    
    if not cachedMultiID then
        return false
    end
    
    local start, duration = GetSpellCooldown(cachedMultiID, BOOKTYPE_SPELL)
    if start and start > 0 then
        local now = GetTime()
        if (now - start) < duration then
            return false
        end
    end
    
    return true
end

-- CanSteadyFitAfterMulti: Check if Steady will fit in next cycle after Multi
local function CanSteadyFitAfterMulti(currentAutoShotTime, redPhaseEnd, steadyCastDuration, weaponSpeed, aimingTime)
    local now = GetTime()
    local elapsedAfterSteady = now - currentAutoShotTime
    local timeLeftInRedNow = redPhaseEnd - elapsedAfterSteady
    
    local multiGCD = 1.5
    local yellowPhase = aimingTime
    local nextRedPhaseDuration = weaponSpeed - aimingTime
    
    local gcdRemainingAfterAutoShot = multiGCD - (timeLeftInRedNow + yellowPhase)
    if gcdRemainingAfterAutoShot < 0 then
        gcdRemainingAfterAutoShot = 0
    end
    
    local allowedDelay = LazyHuntDB.allowedASDelay or 0.0
    local canFit = (gcdRemainingAfterAutoShot + steadyCastDuration) < (nextRedPhaseDuration + allowedDelay)
    
    if debugMode then
        DEFAULT_CHAT_FRAME:AddMessage(string.format(
            "|cFF00FFFFCanSteadyFitAfterMulti: gcdRem=%.2f + steady=%.2f = %.2f < nextRed=%.2f -> %s|r",
            gcdRemainingAfterAutoShot, steadyCastDuration,
            gcdRemainingAfterAutoShot + steadyCastDuration,
            nextRedPhaseDuration + allowedDelay,
            tostring(canFit)))
    end
    
    return canFit
end

-- ============================================================================
-- MAIN ROTATION (FLOWCHART IMPLEMENTATION)
-- ============================================================================

LazyHunt_DoRotation = function()
    if not HamingwaysHunterTools_API then
        return
    end
    
    if not UnitExists("target") or UnitIsDead("target") then
        return
    end
    
    local isShooting = HamingwaysHunterTools_API.IsShooting()
    
    -- Reset if not shooting
    if not isShooting then
        if castingSpell then
            SpellStopCasting()
        end
        castingSpell = nil
        castStartTime = 0
        lastAutoShotTime = 0
        useMultiInsteadOfSteady = false
        shouldCastMultiAfterSteady = false
        return
    end
    
    local isInRedPhase = HamingwaysHunterTools_API.IsInRedPhase()
    
    if not isInRedPhase then
        return
    end
    
    local now = GetTime()
    
    -- Throttle heavy operations
    if (now - lastUpdateTime) < UPDATE_INTERVAL then
        return
    end
    lastUpdateTime = now
    
    -- Update weapon cache
    if (now - lastWeaponCacheTime) > WEAPON_CACHE_INTERVAL then
        cachedWeaponSpeed = HamingwaysHunterTools_API.GetWeaponSpeed()
        cachedAimingTime = HamingwaysHunterTools_API.GetAimingTime()
        lastWeaponCacheTime = now
    end
    
    local currentAutoShotTime = HamingwaysHunterTools_API.GetLastShotTime()
    local weaponSpeed = cachedWeaponSpeed
    local aimingTime = cachedAimingTime
    
    local currentSpeed = UnitRangedDamage("player") or 2.0
    local steadyCastDuration = 1.0 * (currentSpeed / 2.0)
    local redPhaseEnd = weaponSpeed - aimingTime
    
    TryBurst()
    
    -- Initialize on first auto shot
    if lastAutoShotTime == 0 and currentAutoShotTime > 0 then
        lastAutoShotTime = currentAutoShotTime
        castingSpell = nil
        castStartTime = 0
        useMultiInsteadOfSteady = false
        shouldCastMultiAfterSteady = false
    end
    
    -- === NEW AUTO SHOT CYCLE ===
    if currentAutoShotTime > 0 and currentAutoShotTime ~= lastAutoShotTime then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00=== New Auto Shot Cycle ===|r")
        end
        
        lastAutoShotTime = currentAutoShotTime
        castingSpell = nil  -- Reset casting state
        castStartTime = 0
        -- Flags persist across cycles!
    end
    
    if currentAutoShotTime == 0 then
        return
    end
    
    -- === CHECK IF CURRENTLY CASTING ===
    if castingSpell == "STEADY" then
        local steadyElapsed = now - castStartTime
        if steadyElapsed < steadyCastDuration + 0.2 then
            return  -- Still casting
        else
            -- Steady finished!
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Steady finished!|r")
            end
            
            local canSteadyFit = CanSteadyFitAfterMulti(currentAutoShotTime, redPhaseEnd, steadyCastDuration, weaponSpeed, aimingTime)
            
            if canSteadyFit then
                -- Cast Multi after this Steady
                shouldCastMultiAfterSteady = true
                castingSpell = nil  -- Allow next cast
            else
                -- Cast Multi next cycle instead
                useMultiInsteadOfSteady = true
                castingSpell = "STEADY_DONE"  -- Block until next cycle
                return
            end
        end
    elseif castingSpell == "MULTI" then
        local multiElapsed = now - castStartTime
        if multiElapsed < 0.8 then
            return  -- Still casting
        else
            -- Multi finished!
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Multi finished!|r")
            end
            castingSpell = "MULTI_DONE"  -- Block until next cycle
            return
        end
    elseif castingSpell == "STEADY_DONE" or castingSpell == "MULTI_DONE" then
        -- Waiting for next Auto Shot
        return
    end
    
    -- === SPAM PREVENTION ===
    if castingSpell ~= nil then
        return
    end
    
    -- === DECISION LOGIC (FLOWCHART) ===
    
    -- Priority 1: Should cast Multi after Steady?
    if shouldCastMultiAfterSteady then
        shouldCastMultiAfterSteady = false
        
        if not LazyHuntDB.multiShotEnabled then
            return
        end
        
        if not cachedMultiID then
            return
        end
        
        local start, duration = GetSpellCooldown(cachedMultiID, BOOKTYPE_SPELL)
        if start and start > 0 and (now - start) < duration then
            return
        end
        
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Casting Multi after Steady!|r")
        end
        castingSpell = "MULTI"
        castStartTime = now
        if HamingwaysHunterTools_API.NotifyCast then
            HamingwaysHunterTools_API.NotifyCast(cachedMultiName, 0.5)
        end
        CastSpellByName(cachedMultiName)
        return
    end
    
    -- Priority 2: Should cast Multi instead of Steady this cycle?
    if useMultiInsteadOfSteady then
        useMultiInsteadOfSteady = false
        
        if CanMultiFit() then
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Casting Multi instead of Steady!|r")
            end
            castingSpell = "MULTI"
            castStartTime = now
            if HamingwaysHunterTools_API.NotifyCast then
                HamingwaysHunterTools_API.NotifyCast(cachedMultiName, 0.5)
            end
            CastSpellByName(cachedMultiName)
            return
        end
        -- Fall through to cast Steady
    end
    
    -- Default: Cast Steady Shot
    if not cachedSteadyID then
        CacheSpellIDs()
    end
    
    if not cachedSteadyID then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000LazyHunt: Steady Shot not found!|r")
        return
    end
    
    local start, duration = GetSpellCooldown(cachedSteadyID, BOOKTYPE_SPELL)
    if start and start > 0 and (now - start) < duration then
        return
    end
    
    if debugMode then
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Casting Steady Shot!|r")
    end
    castingSpell = "STEADY"
    castStartTime = now
    CastSpellByName(cachedSteadyName)
end

-- ============================================================================
-- EVENT HANDLERS
-- ============================================================================

local frame = CreateFrame("Frame")
frame:RegisterEvent("SPELLCAST_INTERRUPTED")
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function()
    if event == "ADDON_LOADED" and arg1 == "LazyHunt" then
        -- Initialize saved variables individually
        LazyHuntDB = LazyHuntDB or {}
        LazyHuntDB.minimapPos = LazyHuntDB.minimapPos or 225
        LazyHuntDB.allowedASDelay = LazyHuntDB.allowedASDelay or 0.0
        LazyHuntDB.burstEnabled = LazyHuntDB.burstEnabled or false
        LazyHuntDB.burstSunderStacks = LazyHuntDB.burstSunderStacks or 0
        LazyHuntDB.waitForBurstCD = LazyHuntDB.waitForBurstCD or false
        LazyHuntDB.burstCDThreshold = LazyHuntDB.burstCDThreshold or 5
        LazyHuntDB.burstButtonX = LazyHuntDB.burstButtonX or 0
        LazyHuntDB.burstButtonY = LazyHuntDB.burstButtonY or 200
        LazyHuntDB.multiShotEnabled = (LazyHuntDB.multiShotEnabled == nil) and true or LazyHuntDB.multiShotEnabled
        LazyHuntDB.multiButtonX = LazyHuntDB.multiButtonX or 0
        LazyHuntDB.multiButtonY = LazyHuntDB.multiButtonY or 160
        
        CacheSpellIDs()
        
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt v" .. VERSION .. " geladen!|r")
    elseif event == "SPELLCAST_INTERRUPTED" then
        if castingSpell then
            castingSpell = nil
            castStartTime = 0
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000Cast interrupted|r")
            end
        end
    end
end)

-- ============================================================================
-- SLASH COMMANDS
-- ============================================================================

local function SlashCommandHandler(msg)
    msg = string.lower(msg or "")
    
    if msg == "help" or msg == "" then
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt|r v" .. VERSION)
        DEFAULT_CHAT_FRAME:AddMessage("Makro: |cFFFFFF00/script LazyHunt_DoRotation()|r")
        DEFAULT_CHAT_FRAME:AddMessage("Befehle: /lh debug, /lh status, /lh reset")
    elseif msg == "debug" then
        debugMode = not debugMode
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt:|r Debug " .. (debugMode and "AN" or "AUS"))
    elseif msg == "reset" then
        castingSpell = nil
        castStartTime = 0
        lastAutoShotTime = 0
        useMultiInsteadOfSteady = false
        shouldCastMultiAfterSteady = false
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt:|r State reset")
    elseif msg == "status" then
        if HamingwaysHunterTools_API then
            DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt Status:|r")
            DEFAULT_CHAT_FRAME:AddMessage("  Auto Shot: " .. tostring(HamingwaysHunterTools_API.IsShooting()))
            DEFAULT_CHAT_FRAME:AddMessage("  Red Phase: " .. tostring(HamingwaysHunterTools_API.IsInRedPhase()))
            DEFAULT_CHAT_FRAME:AddMessage("  castingSpell: " .. tostring(castingSpell))
            DEFAULT_CHAT_FRAME:AddMessage("  useMultiInsteadOfSteady: " .. tostring(useMultiInsteadOfSteady))
            DEFAULT_CHAT_FRAME:AddMessage("  shouldCastMultiAfterSteady: " .. tostring(shouldCastMultiAfterSteady))
        else
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000LazyHunt: HamingwaysHunterTools not loaded!|r")
        end
    end
end

SLASH_LAZYHUNT1 = "/lazyhunt"
SLASH_LAZYHUNT2 = "/lh"
SlashCmdList["LAZYHUNT"] = SlashCommandHandler

DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt|r v" .. VERSION .. " loaded. Type /lh help")
