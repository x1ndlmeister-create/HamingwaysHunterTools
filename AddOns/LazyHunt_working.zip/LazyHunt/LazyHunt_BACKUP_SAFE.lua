-- LazyHunt - Hunter Rotation Addon for WoW Vanilla 1.12 (Turtle WoW)
-- Version: 3.1.0 - Simplified timing logic
-- Author: Copilot

local VERSION = "3.1.0"

-- Saved Variables (initialized on ADDON_LOADED)
LazyHuntDB = LazyHuntDB or {
    minimapPos = 225,
    allowedASDelay = 0.0,  -- Max allowed Auto Shot delay in seconds (0.0 to 0.5)
    burstEnabled = false,  -- Burst mode on/off
    burstSunderStacks = 0, -- Burst after X stacks of Sunder Armor (0-5, 0 = ignore stacks)
    waitForBurstCD = false, -- Wait for burst if CDs not ready together
    burstCDThreshold = 5,   -- Max CD difference to wait (0-30 seconds)
    burstButtonX = 0,       -- Burst button X position
    burstButtonY = 200,     -- Burst button Y position
    multiShotEnabled = true, -- Multi-Shot toggle (false = Steady only)
    multiButtonX = 0,       -- Multi-Shot button X position
    multiButtonY = 160,     -- Multi-Shot button Y position
}

-- Rotation state
local debugMode = false
local lastAutoShotTime = 0
local steadyCastTime = 0  -- When we started casting Steady (0 = not casting)
local multiCastTime = 0   -- When we started casting Multi (0 = not casting)
local nextCycleSpell = "STEADY"  -- "STEADY" or "MULTI" - what to cast next cycle
local waitingForMultiCD = false  -- Are we waiting for Multi cooldown after Steady?
local hasCastSteadyThisCycle = false  -- Did we cast Steady this auto shot cycle?
local allowSteadyCast = false  -- Flag: Set in yellow phase, reset on cast (SPAM PREVENTION)

-- Performance throttle
local lastUpdateTime = 0
local UPDATE_INTERVAL = 0.05  -- Update every 50ms (20 times per second) - only for heavy operations

-- Cached values to reduce API calls
local cachedWeaponSpeed = 2.0
local cachedAimingTime = 0.5
local lastWeaponCacheTime = 0
local WEAPON_CACHE_INTERVAL = 2.0  -- Update weapon stats every 2 seconds

-- Cached spell IDs (performance optimization)
local cachedSteadyID, cachedSteadyName = nil, nil
local cachedMultiID, cachedMultiName = nil, nil
local cachedRapidFireID = nil

-- Cache spell lookups on load
local function CacheSpellIDs()
    local i = 1
    while true do
        local name = GetSpellName(i, BOOKTYPE_SPELL)
        if not name then break end
        
        if (name == "Steady Shot" or name == "Stetiger Schuss") and not cachedSteadyID then
            cachedSteadyID = i
            cachedSteadyName = name
        elseif (name == "Multi-Shot" or name == "Mehrfachschuss") and not cachedMultiID then
            cachedMultiID = i
            cachedMultiName = name
        elseif name == "Rapid Fire" and not cachedRapidFireID then
            cachedRapidFireID = i
        end
        
        -- Stop early if all found
        if cachedSteadyID and cachedMultiID and cachedRapidFireID then
            break
        end
        
        i = i + 1
    end
end

-- ============================================================================
-- OPTIONS LOG DISPLAY
-- ============================================================================
-- Show notification in options frame log
local function ShowNotification(message)
    if LazyHuntOptionsFrame and LazyHuntOptionsFrame.logDisplay then
        LazyHuntOptionsFrame.logDisplay:SetText(message)
    end
end
-- ============================================================================
-- OPTIONS LOG DISPLAY - END
-- ============================================================================

-- ============================================================================
-- BURST MODE FUNCTIONS
-- ============================================================================
-- Check Sunder Armor stacks on target
local function GetSunderArmorStacks()
    local i = 1
    while UnitDebuff("target", i) do
        local texture = UnitDebuff("target", i)
        -- Sunder Armor icon: Interface\\Icons\\Ability_Warrior_Sunder
        if texture and string.find(texture, "Ability_Warrior_Sunder") then
            return i  -- Return position/stack count
        end
        i = i + 1
    end
    return 0
end

-- Check if burst conditions are met
local function ShouldBurst()
    if not LazyHuntDB.burstEnabled then
        return false
    end
    
    -- Only burst in combat
    if not UnitAffectingCombat("player") then
        return false
    end
    
    -- Check if target exists
    if not UnitExists("target") or UnitIsDead("target") then
        return false
    end
    
    -- Check required Sunder Armor stacks (0 = ignore stacks, burst sofort)
    local requiredStacks = LazyHuntDB.burstSunderStacks or 0
    if requiredStacks > 0 then
        local stacks = GetSunderArmorStacks()
        if stacks < requiredStacks then
            return false
        end
    end
    
    return true
end

-- Try to activate burst (Rapid Fire + On-Use Trinkets)
local function TryBurst()
    if not ShouldBurst() then
        return false
    end
    
    -- Check if we're casting (don't burst during cast)
    if steadyCastTime > 0 or multiCastTime > 0 then
        return false
    end
    
    -- Note: Red phase check removed - Rapid Fire and trinkets are instant and don't clip Auto Shot
    
    -- Use cached Rapid Fire ID (no spell book iteration)
    local rapidFireReady = false
    local rapidFireCD = 999
    if cachedRapidFireID then
        local rapidFireStart, rapidFireDuration = GetSpellCooldown(cachedRapidFireID, BOOKTYPE_SPELL)
        rapidFireCD = (rapidFireStart > 0 and (rapidFireStart + rapidFireDuration - GetTime()) > 1.5) and (rapidFireStart + rapidFireDuration - GetTime()) or 0
        rapidFireReady = rapidFireCD == 0
    end
    
    -- Check trinket slot 13
    local trinket13Ready = false
    local trinket13CD = 999
    local start13, duration13 = GetInventoryItemCooldown("player", 13)
    if start13 then
        trinket13CD = (start13 > 0 and (start13 + duration13 - GetTime()) > 1.5) and (start13 + duration13 - GetTime()) or 0
        trinket13Ready = trinket13CD == 0
    end
    
    -- Check trinket slot 14
    local trinket14Ready = false
    local trinket14CD = 999
    local start14, duration14 = GetInventoryItemCooldown("player", 14)
    if start14 then
        trinket14CD = (start14 > 0 and (start14 + duration14 - GetTime()) > 1.5) and (start14 + duration14 - GetTime()) or 0
        trinket14Ready = trinket14CD == 0
    end
    
    -- At least one ability must be ready
    if not rapidFireReady and not trinket13Ready and not trinket14Ready then
        return false
    end
    
    -- If "Wait for burst CD" is enabled, check if we should wait
    if LazyHuntDB.waitForBurstCD then
        local threshold = LazyHuntDB.burstCDThreshold or 5
        
        -- Check if any ability is ready but others are close to ready
        if rapidFireReady or trinket13Ready or trinket14Ready then
            -- Find the highest CD among abilities that are not ready
            local maxCD = 0
            if not rapidFireReady and rapidFireCD < 999 then
                maxCD = math.max(maxCD, rapidFireCD)
            end
            if not trinket13Ready and trinket13CD < 999 then
                maxCD = math.max(maxCD, trinket13CD)
            end
            if not trinket14Ready and trinket14CD < 999 then
                maxCD = math.max(maxCD, trinket14CD)
            end
            
            -- If any ability is within threshold, wait for it
            if maxCD > 0 and maxCD <= threshold then
                return false
            end
        end
    end
    
    -- All conditions met - activate burst!
    if rapidFireReady then
        CastSpellByName("Rapid Fire")
    end
    
    if trinket13Ready then
        UseInventoryItem(13)
    end
    
    if trinket14Ready then
        UseInventoryItem(14)
    end
    
    -- After burst, update weapon cache immediately (Rapid Fire changes attack speed)
    if rapidFireReady then
        lastWeaponCacheTime = 0  -- Force cache update on next rotation check
    end
    
    return true
end
-- ============================================================================
-- BURST MODE FUNCTIONS - END
-- ============================================================================

-- Main rotation function (called from macro)
LazyHunt_DoRotation = function()
    -- Fast early-exit checks (no throttle, always check these)
    -- Check if HamingwaysHunterTools is loaded
    if not HamingwaysHunterTools_API then
        return  -- Silent fail, no message spam
    end
    
    -- Check if we have a target
    if not UnitExists("target") or UnitIsDead("target") then
        return
    end
    
    -- Get basic state (fast API calls)
    local isShooting = HamingwaysHunterTools_API.IsShooting()
    
    -- CRITICAL: If not shooting, immediately cancel any active cast and reset
    if not isShooting then
        if steadyCastTime > 0 or multiCastTime > 0 then
            SpellStopCasting()
            steadyCastTime = 0
            multiCastTime = 0
            waitingForMultiCD = false
            hasCastSteadyThisCycle = false
        end
        return
    end
    
    local isInRedPhase = HamingwaysHunterTools_API.IsInRedPhase()
    local isInYellowPhase = HamingwaysHunterTools_API.IsInYellowPhase()
    
    -- Set flag in yellow phase: Allow Steady cast in next red phase
    if isInYellowPhase then
        allowSteadyCast = true
    end

    -- Not in red phase? Can't cast anything
    if not isInRedPhase then
        return
    end
    
    -- Get time once for all checks
    local now = GetTime()
    
    -- Already casting? Quick check if still busy
    if steadyCastTime > 0 then
        -- Use cached weapon speed for cast duration estimate
        local steadyCastDuration = 1.0 * (cachedWeaponSpeed / 2.0)
        if (now - steadyCastTime) < steadyCastDuration + 0.2 then
            return  -- Still casting Steady
        end
    end
    
    if multiCastTime > 0 and (now - multiCastTime) < 0.8 then
        return  -- Still casting Multi
    end
    
    -- Throttle heavy operations (full rotation logic)
    if (now - lastUpdateTime) < UPDATE_INTERVAL then
        return
    end
    lastUpdateTime = now
    
    -- Update weapon cache if needed
    if (now - lastWeaponCacheTime) > WEAPON_CACHE_INTERVAL then
        cachedWeaponSpeed = HamingwaysHunterTools_API.GetWeaponSpeed()
        cachedAimingTime = HamingwaysHunterTools_API.GetAimingTime()
        lastWeaponCacheTime = now
    end
    
    -- Heavy operations start here (get full state)
    local currentAutoShotTime = HamingwaysHunterTools_API.GetLastShotTime()
    local weaponSpeed = cachedWeaponSpeed
    local aimingTime = cachedAimingTime
    
    -- Try burst (only when rotation is active: shooting and in combat)
    TryBurst()
    
    -- Debug output (disabled in production for performance)
    -- if debugMode then
    --     DEFAULT_CHAT_FRAME:AddMessage(string.format(
    --         "shoot=%s red=%s steady=%.1f multi=%.1f next=%s", 
    --         tostring(isShooting), tostring(isInRedPhase), 
    --         steadyCastTime, multiCastTime, nextCycleSpell))
    -- end
    
    -- Safety: If lastAutoShotTime is 0 (after reload), force reset all states
    if lastAutoShotTime == 0 then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFF00FFFF=== Post-reload safety reset ===|r")
        end
        steadyCastTime = 0
        multiCastTime = 0
        waitingForMultiCD = false
        nextCycleSpell = "STEADY"
        hasCastSteadyThisCycle = false
        
        -- Don't cast anything until we have valid auto shot timing
        if currentAutoShotTime == 0 then
            return
        end
    end
    
    -- Initialize lastAutoShotTime on first valid auto shot (after reload/login)
    if lastAutoShotTime == 0 and currentAutoShotTime > 0 then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFF00FFFF=== Init: Setting lastAutoShotTime=%.1f ===|r", currentAutoShotTime))
        end
        lastAutoShotTime = currentAutoShotTime
        steadyCastTime = 0
        multiCastTime = 0
        waitingForMultiCD = false
        nextCycleSpell = "STEADY"
        allowSteadyCast = true  -- Allow cast immediately on first auto shot
        hasCastSteadyThisCycle = false
    end
    
    -- Reset on new auto shot cycle
    if currentAutoShotTime > 0 and currentAutoShotTime ~= lastAutoShotTime then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFF00FF00=== New cycle: last=%.1f new=%.1f next=%s ===", lastAutoShotTime, currentAutoShotTime, nextCycleSpell))
        end
        lastAutoShotTime = currentAutoShotTime
        steadyCastTime = 0
        multiCastTime = 0
        waitingForMultiCD = false
        hasCastSteadyThisCycle = false
        -- Note: nextCycleSpell is NOT reset here - it persists into next cycle
        -- Note: allowSteadyCast is NOT reset here - it's set in yellow phase, used in red phase
    end
    
    -- Force reset if steadyCastTime is stuck (older than 3 seconds)
    if steadyCastTime > 0 and (now - steadyCastTime) > 3 then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFFFF0000Force reset: steadyCastTime stuck at %.1f (%.1fs ago)|r", steadyCastTime, now - steadyCastTime))
        end
        steadyCastTime = 0
        multiCastTime = 0
        waitingForMultiCD = false
    end
    
    -- Don't cast before first auto shot
    if currentAutoShotTime == 0 then
        return
    end
    
    -- Only cast in red phase
    if not isInRedPhase then
        return
    end
    
    -- Calculate time left in red phase
    local elapsed = now - currentAutoShotTime
    local redPhaseEnd = weaponSpeed - aimingTime
    local timeLeftInRed = redPhaseEnd - elapsed
    
    if debugMode and timeLeftInRed < 0 then
        DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFFFF0000Red phase ended %.2fs ago|r", -timeLeftInRed))
    end
    
    -- Estimate Steady Shot cast time (1s base + haste)
    local currentSpeed = UnitRangedDamage("player") or 2.0
    local steadyCastDuration = 1.0 * (currentSpeed / 2.0)
    
    -- Wait if currently casting
    if isCasting then
        if GetTime() < castEndTime then
            if debugMode then
                local remaining = castEndTime - GetTime()
                DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFFFFAA00Still casting %.1fs|r", remaining))
            end
            return
        else
            -- Cast finished
            isCasting = false
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Cast finished|r")
            end
        end
    end
    
    -- If waiting for Multi CD after Steady, keep trying Multi
    if waitingForMultiCD then
        -- Skip Multi-Shot if disabled
        if not LazyHuntDB.multiShotEnabled then
            waitingForMultiCD = false
            steadyCastTime = -1
            hasCastSteadyThisCycle = false
            nextCycleSpell = "STEADY"
            return
        end
        
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFF00FFFFWaiting for Multi CD, trying now...|r")
        end
        
        -- Use cached Multi-Shot ID
        if cachedMultiID then
            -- Check cooldown
            local start, duration = GetSpellCooldown(cachedMultiID, BOOKTYPE_SPELL)
            if not start or start == 0 or (now - start) >= duration then
                -- Cast Multi-Shot
                if debugMode then
                    DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Casting Multi-Shot (after CD wait)!|r")
                end
                multiCastTime = now
                waitingForMultiCD = false
                steadyCastTime = -1  -- Mark cycle as complete
                if HamingwaysHunterTools_API.NotifyCast then
                    HamingwaysHunterTools_API.NotifyCast(cachedMultiName, 0.5)
                end
                CastSpellByName(cachedMultiName)
                return
            else
                if debugMode then
                    local remaining = duration - (now - start)
                    DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFFFFAA00Multi still on CD: %.1fs|r", remaining))
                end
                return  -- Keep waiting
            end
        else
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000Multi-Shot not found in cache!|r")
            end
            waitingForMultiCD = false
            return
        end
    end
    
    -- Check if Steady is currently casting
    if steadyCastTime > 0 then
        local steadyElapsed = now - steadyCastTime
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFFAAFFFFSteady: elapsed=%.2f duration=%.2f castTime=%.2f|r", steadyElapsed, steadyCastDuration, steadyCastTime))
        end
        if steadyElapsed < steadyCastDuration + 0.2 then
            -- Still casting Steady
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFFFFAA00Steady casting %.1fs|r", steadyElapsed))
            end
            return
        else
            -- Steady finished
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Steady finished! Setting steadyCastTime=-1|r")
            end
            steadyCastTime = -1  -- Mark as completed this cycle
            
            -- Calculate if we have enough time for Multi in current red phase
            local nowAfterSteady = GetTime()
            local elapsedAfterSteady = nowAfterSteady - currentAutoShotTime
            local timeLeftInRedNow = redPhaseEnd - elapsedAfterSteady
            
            local multiGCD = 1.5  -- Multi-Shot GCD (1.5s in Vanilla 1.12)
            local yellowPhase = aimingTime  -- 0.5s yellow phase
            local steadyDuration = steadyCastDuration
            local nextRedPhaseDuration = weaponSpeed - aimingTime
            
            -- Calculate GCD remaining after auto shot fires
            -- Multi GCD starts now, but auto shot fires after (timeLeftInRedNow + yellowPhase)
            local gcdRemainingAfterAutoShot = multiGCD - (timeLeftInRedNow + yellowPhase)
            if gcdRemainingAfterAutoShot < 0 then
                gcdRemainingAfterAutoShot = 0
            end
            
            -- Check: Can Steady finish in next red phase AFTER GCD remainder?
            local allowedDelay = LazyHuntDB.allowedASDelay or 0.0
            local canSteadyFitNextCycle = (gcdRemainingAfterAutoShot + steadyDuration) < (nextRedPhaseDuration + allowedDelay)
            
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage(string.format(
                    "|cFF00FFFFMulti check: GCD=%.2f - (redLeft=%.2f + yellow=%.2f) = gcdRem=%.2f | (%.2f+%.2f=%.2f) < (%.2f+%.2f=%.2f) = %s|r", 
                    multiGCD, timeLeftInRedNow, yellowPhase, gcdRemainingAfterAutoShot,
                    gcdRemainingAfterAutoShot, steadyDuration, gcdRemainingAfterAutoShot + steadyDuration, 
                    nextRedPhaseDuration, allowedDelay, nextRedPhaseDuration + allowedDelay, tostring(canSteadyFitNextCycle)))
            end
            
            if canSteadyFitNextCycle then
                -- Skip Multi-Shot if disabled
                if not LazyHuntDB.multiShotEnabled then
                    if debugMode then
                        DEFAULT_CHAT_FRAME:AddMessage("|cFFFF8800Multi-Shot disabled, casting Steady instead|r")
                    end
                    nextCycleSpell = "STEADY"
                    return
                end
                
                -- Schedule Multi-Shot attempt (Steady will fit next cycle after GCD remainder)
                waitingForMultiCD = true
                ShowNotification(string.format("Multi-Shot nach Steady: GCD-Rest (%.2fs) + Steady (%.1fs) = %.2fs < Red Phase (%.1fs) + Delay (%.2fs)", gcdRemainingAfterAutoShot, steadyDuration, gcdRemainingAfterAutoShot + steadyDuration, nextRedPhaseDuration, allowedDelay))
                if debugMode then
                    DEFAULT_CHAT_FRAME:AddMessage("|cFF00FFFFScheduling Multi-Shot attempt|r")
                end
                return
            else
                if debugMode then
                    DEFAULT_CHAT_FRAME:AddMessage("|cFFFF8800Steady won't fit next cycle after GCD remainder - will cast Multi next cycle|r")
                end
                ShowNotification(string.format("Multi-Shot verschoben: Steady nach GCD-Rest (%.2fs+%.1fs=%.2fs) > Red Phase (%.1fs) + Delay (%.2fs)", gcdRemainingAfterAutoShot, steadyDuration, gcdRemainingAfterAutoShot + steadyDuration, nextRedPhaseDuration, allowedDelay))
                nextCycleSpell = "MULTI"
                return
            end
        end
    end
    
    -- Check if Multi is currently casting
    if multiCastTime > 0 then
        local multiElapsed = now - multiCastTime
        if multiElapsed < 0.8 then  -- GCD + buffer
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFFFFAA00Multi casting|r")
            end
            return
        else
            -- Multi finished
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Multi finished!|r")
            end
            multiCastTime = -1  -- Mark as completed
            waitingForMultiCD = false
            return
        end
    end
    
    -- If we already cast Steady this cycle, don't cast again (SPAM PREVENTION)
    if hasCastSteadyThisCycle and not waitingForMultiCD and nextCycleSpell == "STEADY" then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFFAA00Already cast Steady this cycle - blocked|r")
        end
        return
    end
    
    -- Check if we have enough time to cast Steady
    if timeLeftInRed < steadyCastDuration then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFFFFAA00Not enough time (%.2fs < %.2fs)|r", timeLeftInRed, steadyCastDuration))
        end
        return
    end
    
    -- Decide which spell to cast based on nextCycleSpell
    if nextCycleSpell == "MULTI" then
        -- Skip Multi-Shot if disabled
        if not LazyHuntDB.multiShotEnabled then
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFFFF8800Multi-Shot disabled, switching to Steady|r")
            end
            nextCycleSpell = "STEADY"
        else
            -- Cast Multi-Shot instead of Steady
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFF00FFFFCasting Multi instead of Steady this cycle|r")
            end
            
            -- Use cached Multi-Shot ID
            if cachedMultiID then
                -- Check cooldown
                local start, duration = GetSpellCooldown(cachedMultiID, BOOKTYPE_SPELL)
                if not start or start == 0 or (now - start) >= duration then
                    if debugMode then
                        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Casting Multi-Shot (instead of Steady)!|r")
                    end
                    multiCastTime = now
                    nextCycleSpell = "STEADY"  -- Back to normal
                    if HamingwaysHunterTools_API.NotifyCast then
                        HamingwaysHunterTools_API.NotifyCast(cachedMultiName, 0.5)
                    end
                    CastSpellByName(cachedMultiName)
                    return
                else
                    if debugMode then
                        local remaining = duration - (now - start)
                        DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFFFFAA00Multi on CD: %.1fs, fallback to Steady|r", remaining))
                    end
                    -- Fallback to Steady if Multi on CD
                    nextCycleSpell = "STEADY"
                end
            else
                if debugMode then
                    DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000Multi-Shot not found in cache, fallback to Steady|r")
                end
                nextCycleSpell = "STEADY"
            end
        end
    end
    
    -- Find Steady Shot (using cache or fallback)
    if not cachedSteadyID then
        CacheSpellIDs()
    end
    
    if not cachedSteadyID then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000LazyHunt: Steady Shot not found!|r")
        return
    end
    
    -- Check cooldown
    local start, duration = GetSpellCooldown(cachedSteadyID, BOOKTYPE_SPELL)
    if start and start > 0 and (now - start) < duration then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFFAA00Steady on CD|r")
        end
        return
    end
    
    -- SPAM PREVENTION: Only cast if flag is set (flag is set in yellow phase)
    if not allowSteadyCast then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000SPAM BLOCKED: allowSteadyCast flag not set|r")
        end
        return
    end
    
    -- Cast Steady Shot
    if debugMode then
        DEFAULT_CHAT_FRAME:AddMessage(string.format("|cFF00FF00Casting Steady Shot! steadyCastTime=%.2f -> %.2f|r", steadyCastTime, now))
    end
    steadyCastTime = now
    allowSteadyCast = false  -- Reset flag immediately after cast
    hasCastSteadyThisCycle = true  -- Mark that we cast Steady this cycle
    CastSpellByName(cachedSteadyName)
end

-- Event frame for interrupts and initialization
local frame = CreateFrame("Frame")
frame:RegisterEvent("SPELLCAST_INTERRUPTED")
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function()
    if event == "ADDON_LOADED" and arg1 == "LazyHunt" then
        -- Initialize saved variables
        LazyHuntDB = LazyHuntDB or {
            minimapPos = 225,
            allowedASDelay = 0.0,
        }
        
        -- Cache spell IDs for performance
        CacheSpellIDs()
        
        -- Minimap button is created by LazyHunt_Minimap.lua
        
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt v" .. VERSION .. " geladen!|r")
    elseif event == "SPELLCAST_INTERRUPTED" then
        -- Reset cast timers so we can retry
        if steadyCastTime > 0 then
            steadyCastTime = 0
            allowSteadyCast = false
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000Steady interrupted|r")
            end
        end
        if multiCastTime > 0 then
            multiCastTime = 0
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000Multi interrupted|r")
            end
        end
    end
end)

-- Slash commands
local function SlashCommandHandler(msg)
    msg = string.lower(msg or "")
    
    if msg == "help" or msg == "" then
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt|r v" .. VERSION)
        DEFAULT_CHAT_FRAME:AddMessage("Makro: |cFFFFFF00/script LazyHunt_DoRotation()|r")
        DEFAULT_CHAT_FRAME:AddMessage("Befehle: /lh debug, /lh status, /lh reset")
    elseif msg == "debug" then
        debugMode = not debugMode
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt:|r Debug " .. (debugMode and "AN" or "AUS"))
    elseif msg == "reset" then
        steadyCastTime = 0
        multiCastTime = 0
        lastAutoShotTime = 0
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt:|r State reset")
    elseif msg == "status" then
        if HamingwaysHunterTools_API then
            DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt Status:|r")
            DEFAULT_CHAT_FRAME:AddMessage("  Auto Shot: " .. tostring(HamingwaysHunterTools_API.IsShooting()))
            DEFAULT_CHAT_FRAME:AddMessage("  Red Phase: " .. tostring(HamingwaysHunterTools_API.IsInRedPhase()))
            DEFAULT_CHAT_FRAME:AddMessage("  Yellow Phase: " .. tostring(HamingwaysHunterTools_API.IsInYellowPhase()))
            DEFAULT_CHAT_FRAME:AddMessage("  Weapon Speed: " .. string.format("%.2f", HamingwaysHunterTools_API.GetWeaponSpeed()))
            DEFAULT_CHAT_FRAME:AddMessage("  steadyCastTime: " .. string.format("%.2f", steadyCastTime))
            DEFAULT_CHAT_FRAME:AddMessage("  multiCastTime: " .. string.format("%.2f", multiCastTime))
            DEFAULT_CHAT_FRAME:AddMessage("  lastAutoShotTime: " .. string.format("%.2f", lastAutoShotTime))
        else
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000LazyHunt: HamingwaysHunterTools not loaded!|r")
        end
    end
end

-- Register slash commands
SLASH_LAZYHUNT1 = "/lazyhunt"
SLASH_LAZYHUNT2 = "/lh"
SlashCmdList["LAZYHUNT"] = SlashCommandHandler

-- Startup message
DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt|r v" .. VERSION .. " loaded. Type /lh help")
