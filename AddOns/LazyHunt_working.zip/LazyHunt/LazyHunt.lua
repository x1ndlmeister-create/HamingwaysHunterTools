-- LazyHunt - Hunter Rotation Addon for WoW Vanilla 1.12 (Turtle WoW)
-- Version: 3.1.0 - Simplified timing logic
-- Author: Copilot

local VERSION = "3.1.0"

-- Global flag to indicate addon is fully loaded and ready
LazyHunt_IsLoaded = false

-- Saved Variables (initialized on ADDON_LOADED)
LazyHuntDB = LazyHuntDB or {
    minimapPos = 225,
    allowedASDelay = 0.0,  -- Max allowed Auto Shot delay in seconds (0.0 to 0.5)
    burstEnabled = false,  -- Burst mode on/off
    burstSunderStacks = 0, -- Burst after X stacks of Sunder Armor (0-5, 0 = ignore stacks)
    waitForBurstCD = false, -- Wait for burst if CDs not ready together
    burstCDThreshold = 5,   -- Max CD difference to wait (0-30 seconds)
    burstButtonX = 0,       -- Burst button X position
    burstButtonY = 200,     -- Burst button Y position
    multiShotEnabled = true, -- Multi-Shot toggle (false = Steady only)
    multiButtonX = 0,       -- Multi-Shot button X position
    multiButtonY = 160,     -- Multi-Shot button Y position
}

-- State Machine: Main Step
local STEP_INIT = "INIT"
local STEP_WORK = "WORK"
local currentStep = STEP_INIT

-- State Machine: Rotation Step (what to cast in RED phase)
local ROTA_DO_NOTHING = "DO_NOTHING"
local ROTA_DO_MULTI = "DO_MULTI"
local ROTA_DO_STEADY = "DO_STEADY"
local ROTA_DO_MULTIAFTERSTEADY = "DO_MULTIAFTERSTEADY"
local currentRotaStep = ROTA_DO_NOTHING

-- Rotation state
local debugMode = false
local lastAutoShotTime = 0
local steadyCastTime = 0  -- When we started casting Steady (0 = not casting, >0 = timestamp)
local multiCastTime = 0   -- When we started casting Multi (0 = not casting, >0 = timestamp)
local shouldCastMultiInsteadOfSteady = false  -- Flag: Cast Multi instead of Steady this cycle
local decisionMadeInYellow = false  -- Flag: Decision already made in Yellow Phase (reset in Red Phase)

-- ============================================================================
-- DEBUG: Track rotation step changes (DISABLED - kann später reaktiviert werden)
-- ============================================================================
--[[ DISABLED DEBUG CODE
local lastRotaStep = ROTA_DO_NOTHING
local function DebugRotaStepChange(newStep)
    if newStep ~= lastRotaStep then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFFFAA00[ROTA] " .. (lastRotaStep or "nil") .. " -> " .. newStep .. "|r")
        lastRotaStep = newStep
    end
end
--]]
-- Dummy function to prevent errors
local function DebugRotaStepChange(newStep)
    -- Do nothing
end

-- Cached values to reduce API calls
local cachedWeaponSpeed = 2.0
local cachedAimingTime = 0.5
local lastWeaponCacheTime = 0
local WEAPON_CACHE_INTERVAL = 2.0  -- Update weapon stats every 2 seconds

-- Cached spell IDs (performance optimization)
local cachedSteadyID, cachedSteadyName = nil, nil
local cachedMultiID, cachedMultiName = nil, nil
local cachedRapidFireID = nil

-- Cache spell lookups on load
local function CacheSpellIDs()
    local i = 1
    while true do
        local name = GetSpellName(i, BOOKTYPE_SPELL)
        if not name then break end
        
        if (name == "Steady Shot" or name == "Stetiger Schuss") and not cachedSteadyID then
            cachedSteadyID = i
            cachedSteadyName = name
        elseif (name == "Multi-Shot" or name == "Mehrfachschuss") and not cachedMultiID then
            cachedMultiID = i
            cachedMultiName = name
        elseif name == "Rapid Fire" and not cachedRapidFireID then
            cachedRapidFireID = i
        end
        
        -- Stop early if all found
        if cachedSteadyID and cachedMultiID and cachedRapidFireID then
            break
        end
        
        i = i + 1
    end
end

-- ============================================================================
-- OPTIONS LOG DISPLAY
-- ============================================================================
-- Show notification in options frame log
local function ShowNotification(message)
    if LazyHuntOptionsFrame and LazyHuntOptionsFrame.logDisplay then
        LazyHuntOptionsFrame.logDisplay:SetText(message)
    end
end
-- ============================================================================
-- OPTIONS LOG DISPLAY - END
-- ============================================================================

-- ============================================================================
-- BURST MODE FUNCTIONS
-- ============================================================================
-- Check Sunder Armor stacks on target
local function GetSunderArmorStacks()
    local i = 1
    while UnitDebuff("target", i) do
        local texture = UnitDebuff("target", i)
        -- Sunder Armor icon: Interface\\Icons\\Ability_Warrior_Sunder
        if texture and string.find(texture, "Ability_Warrior_Sunder") then
            return i  -- Return position/stack count
        end
        i = i + 1
    end
    return 0
end

-- Check if burst conditions are met
local function ShouldBurst()
    if not LazyHuntDB.burstEnabled then
        return false
    end
    
    -- Only burst in combat
    if not UnitAffectingCombat("player") then
        return false
    end
    
    -- Check if target exists
    if not UnitExists("target") or UnitIsDead("target") then
        return false
    end
    
    -- Check required Sunder Armor stacks (0 = ignore stacks, burst sofort)
    local requiredStacks = LazyHuntDB.burstSunderStacks or 0
    if requiredStacks > 0 then
        local stacks = GetSunderArmorStacks()
        if stacks < requiredStacks then
            return false
        end
    end
    
    return true
end

-- Try to activate burst (Rapid Fire + On-Use Trinkets)
local function TryBurst()
    if not ShouldBurst() then
        return false
    end
    
    -- Check if we're casting (don't burst during cast)
    if steadyCastTime > 0 or multiCastTime > 0 then
        return false
    end
    
    -- Note: Red phase check removed - Rapid Fire and trinkets are instant and don't clip Auto Shot
    
    -- Use cached Rapid Fire ID (no spell book iteration)
    local rapidFireReady = false
    local rapidFireCD = 999
    if cachedRapidFireID then
        local rapidFireStart, rapidFireDuration = GetSpellCooldown(cachedRapidFireID, BOOKTYPE_SPELL)
        rapidFireCD = (rapidFireStart > 0 and (rapidFireStart + rapidFireDuration - GetTime()) > 1.5) and (rapidFireStart + rapidFireDuration - GetTime()) or 0
        rapidFireReady = rapidFireCD == 0
    end
    
    -- Check trinket slot 13
    local trinket13Ready = false
    local trinket13CD = 999
    local start13, duration13 = GetInventoryItemCooldown("player", 13)
    if start13 then
        trinket13CD = (start13 > 0 and (start13 + duration13 - GetTime()) > 1.5) and (start13 + duration13 - GetTime()) or 0
        trinket13Ready = trinket13CD == 0
    end
    
    -- Check trinket slot 14
    local trinket14Ready = false
    local trinket14CD = 999
    local start14, duration14 = GetInventoryItemCooldown("player", 14)
    if start14 then
        trinket14CD = (start14 > 0 and (start14 + duration14 - GetTime()) > 1.5) and (start14 + duration14 - GetTime()) or 0
        trinket14Ready = trinket14CD == 0
    end
    
    -- At least one ability must be ready
    if not rapidFireReady and not trinket13Ready and not trinket14Ready then
        return false
    end
    
    -- If "Wait for burst CD" is enabled, check if we should wait
    if LazyHuntDB.waitForBurstCD then
        local threshold = LazyHuntDB.burstCDThreshold or 5
        
        -- Check if any ability is ready but others are close to ready
        if rapidFireReady or trinket13Ready or trinket14Ready then
            -- Find the highest CD among abilities that are not ready
            local maxCD = 0
            if not rapidFireReady and rapidFireCD < 999 then
                maxCD = math.max(maxCD, rapidFireCD)
            end
            if not trinket13Ready and trinket13CD < 999 then
                maxCD = math.max(maxCD, trinket13CD)
            end
            if not trinket14Ready and trinket14CD < 999 then
                maxCD = math.max(maxCD, trinket14CD)
            end
            
            -- If any ability is within threshold, wait for it
            if maxCD > 0 and maxCD <= threshold then
                return false
            end
        end
    end
    
    -- All conditions met - activate burst!
    if rapidFireReady then
        CastSpellByName("Rapid Fire")
    end
    
    if trinket13Ready then
        UseInventoryItem(13)
    end
    
    if trinket14Ready then
        UseInventoryItem(14)
    end
    
    -- After burst, update weapon cache immediately (Rapid Fire changes attack speed)
    if rapidFireReady then
        lastWeaponCacheTime = 0  -- Force cache update on next rotation check
    end
    
    return true
end
-- ============================================================================
-- BURST MODE FUNCTIONS - END
-- ============================================================================

-- Main rotation function (called from macro every 10ms)
local function LazyHunt_DoRotation_Internal()
    local now = GetTime()
    
    -- ========================================================================
    -- STATE MACHINE: MAIN STEP
    -- ========================================================================
    
    if currentStep == STEP_INIT then
        -- ====================================================================
        -- INIT: All initialization checks
        -- ====================================================================
        
        -- Check if addon is fully loaded
        if not LazyHunt_IsLoaded then
            return
        end
        
        -- Check if HamingwaysHunterTools is loaded
        if not HamingwaysHunterTools_API then
            return
        end
        
        -- Cache spell IDs (must succeed for init to complete)
        CacheSpellIDs()
        if not cachedSteadyID or not cachedMultiID then
            return  -- Spells not found yet
        end
        
        -- Check if we have first auto shot (init lastAutoShotTime)
        local currentAutoShotTime = HamingwaysHunterTools_API.GetLastShotTime()
        if currentAutoShotTime > 0 and lastAutoShotTime == 0 then
            lastAutoShotTime = currentAutoShotTime
            currentRotaStep = ROTA_DO_NOTHING
            -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFF00FFFF=== INIT complete, switching to WORK ===|r")
            end
            currentStep = STEP_WORK
        end
        
        return
    end
    
    if currentStep == STEP_WORK then
        -- ====================================================================
        -- WORK: Main rotation logic
        -- ====================================================================
        
        -- Check if we have a target
        if not UnitExists("target") or UnitIsDead("target") then
            return
        end
        
        -- Get basic state
        local isShooting = HamingwaysHunterTools_API.IsShooting()
        
        -- If not shooting, cancel all casts and reset rotation
        if not isShooting then
            if steadyCastTime > 0 or multiCastTime > 0 or currentRotaStep ~= ROTA_DO_NOTHING or shouldCastMultiInsteadOfSteady then
                SpellStopCasting()
                steadyCastTime = 0
                multiCastTime = 0
                currentRotaStep = ROTA_DO_NOTHING
                shouldCastMultiInsteadOfSteady = false
                -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
            end
            return
        end
        
        local isInYellowPhase = HamingwaysHunterTools_API.IsInYellowPhase()
        local isInRedPhase = HamingwaysHunterTools_API.IsInRedPhase()
        
        -- ================================================================
        -- YELLOW PHASE: Decision logic
        -- ================================================================
        if isInYellowPhase then
            -- CRITICAL: If decision already made, do nothing (prevent re-triggering)
            if decisionMadeInYellow then
                return
            end
            
            -- If we have a rotation step and are still casting, wait for cast to finish
            if currentRotaStep ~= ROTA_DO_NOTHING and HamingwaysHunterTools_API.IsCasting() then
                return  -- Still casting, wait
            end
            
            -- Clean up old step if present (cast has finished or never started)
            if currentRotaStep ~= ROTA_DO_NOTHING then
                steadyCastTime = 0
                multiCastTime = 0
                currentRotaStep = ROTA_DO_NOTHING
                -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
            end
            
            -- Decide what to cast (only if DO_NOTHING and decision not yet made)
            if currentRotaStep == ROTA_DO_NOTHING and not decisionMadeInYellow then
                if not HamingwaysHunterTools_API.IsCasting() then
                    -- Try burst before making decision
                    TryBurst()
                    
                    if shouldCastMultiInsteadOfSteady then
                        currentRotaStep = ROTA_DO_MULTI
                    else
                        currentRotaStep = ROTA_DO_STEADY
                    end
                    -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
                    
                    -- Mark decision as made
                    decisionMadeInYellow = true
                end
            end
            
            return
        end
        
        -- ================================================================
        -- RED PHASE: Execution logic
        -- ================================================================
        if isInRedPhase then
            -- Reset decision flag (allow new decision in next Yellow Phase)
            decisionMadeInYellow = false
            
            -- Check if auto shot still active
            local currentAutoShotTime = HamingwaysHunterTools_API.GetLastShotTime()
            if currentAutoShotTime == 0 then
                -- No auto shot - cancel all and reset
                SpellStopCasting()
                steadyCastTime = 0
                multiCastTime = 0
                currentRotaStep = ROTA_DO_NOTHING
                -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
                return
            end
            
            -- ============================================================
            -- ROTATION STEP SWITCH: Execute based on current step
            -- ============================================================
            if currentRotaStep == ROTA_DO_NOTHING then
                -- Do nothing, wait for yellow phase decision
                return
                
            elseif currentRotaStep == ROTA_DO_MULTI then
                -- Cast Multi-Shot (enabled check only)
                if LazyHuntDB.multiShotEnabled then
                    -- Update weapon cache for fit calculation
                    if (now - lastWeaponCacheTime) > WEAPON_CACHE_INTERVAL then
                        local newSpeed = HamingwaysHunterTools_API.GetWeaponSpeed()
                        local newAiming = HamingwaysHunterTools_API.GetAimingTime()
                        if newSpeed and newSpeed > 0 then cachedWeaponSpeed = newSpeed end
                        if newAiming and newAiming > 0 then cachedAimingTime = newAiming end
                        lastWeaponCacheTime = now
                    end
                    -- Check CanMultiFit()
                    local elapsed = now - currentAutoShotTime
                    local redPhaseEnd = cachedWeaponSpeed - cachedAimingTime
                    local timeLeftInRed = redPhaseEnd - elapsed
                    
                    local start, duration = GetSpellCooldown(cachedMultiID, BOOKTYPE_SPELL)
                    local multiCD = 0
                    if start and start > 0 then
                        multiCD = duration - (now - start)
                        if multiCD < 0 then multiCD = 0 end
                    end
                    
                    local multiTotalTime = 1.5 + multiCD
                    
                    if multiTotalTime < timeLeftInRed then
                        -- Cast Multi
                        multiCastTime = now
                        currentRotaStep = ROTA_DO_NOTHING
                        shouldCastMultiInsteadOfSteady = false
                        HamingwaysHunterTools_API.NotifyCast(cachedMultiName, 0.5)
                        CastSpellByName(cachedMultiName)
                    end
                end
                
                currentRotaStep = ROTA_DO_NOTHING
                shouldCastMultiInsteadOfSteady = false
                -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
                return
                
            elseif currentRotaStep == ROTA_DO_STEADY then
                -- Cast Steady Shot once (will queue if GCD active)
                CastSpellByName(cachedSteadyName)
                
                -- Verify cast started before transitioning
                if HamingwaysHunterTools_API.IsCasting() then
                    steadyCastTime = now
                    currentRotaStep = ROTA_DO_MULTIAFTERSTEADY
                    -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
                end
                return
                
            elseif currentRotaStep == ROTA_DO_MULTIAFTERSTEADY then
                -- First: Check if Steady is still casting
                if steadyCastTime > 0 then
                    local steadyCastDuration = 1.0 * (cachedWeaponSpeed / 2.0)
                    if (now - steadyCastTime) < steadyCastDuration + 0.2 then
                        return  -- Still casting Steady
                    else
                        -- Steady finished!
                        steadyCastTime = 0
                    end
                end
                
                -- Check if Multi-Shot is ready (CD check first, before any calculations)
                if not LazyHuntDB.multiShotEnabled then
                    -- Multi disabled, reset flag and go back to DO_NOTHING
                    shouldCastMultiInsteadOfSteady = false
                    currentRotaStep = ROTA_DO_NOTHING
                    -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
                    return
                end
                
                local start, duration = GetSpellCooldown(cachedMultiID, BOOKTYPE_SPELL)
                local isMultiReady = (not start or start == 0 or duration <= 1.5)
                
                if not isMultiReady then
                    -- Multi not ready, reset flag and go back to DO_NOTHING
                    shouldCastMultiInsteadOfSteady = false
                    currentRotaStep = ROTA_DO_NOTHING
                    -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
                    return
                end
                
                -- Multi is ready, now do fit calculations
                -- Update weapon cache for fit calculation
                if (now - lastWeaponCacheTime) > WEAPON_CACHE_INTERVAL then
                    local newSpeed = HamingwaysHunterTools_API.GetWeaponSpeed()
                    local newAiming = HamingwaysHunterTools_API.GetAimingTime()
                    if newSpeed and newSpeed > 0 then cachedWeaponSpeed = newSpeed end
                    if newAiming and newAiming > 0 then cachedAimingTime = newAiming end
                    lastWeaponCacheTime = now
                end
                
                -- Check if we can cast Multi after Steady
                local elapsed = now - currentAutoShotTime
                local redPhaseEnd = cachedWeaponSpeed - cachedAimingTime
                local timeLeftInRed = redPhaseEnd - elapsed
                
                local multiGCD = 1.5
                local yellowPhase = cachedAimingTime
                local nextRedPhaseDuration = cachedWeaponSpeed - cachedAimingTime
                local steadyCastDuration = 1.0 * (cachedWeaponSpeed / 2.0)
                
                -- Calculate GCD remaining after auto shot fires
                local gcdRemainingAfterAutoShot = multiGCD - (timeLeftInRed + yellowPhase)
                if gcdRemainingAfterAutoShot < 0 then gcdRemainingAfterAutoShot = 0 end
                
                -- Check: Can Steady finish in next red phase?
                local allowedDelay = LazyHuntDB.allowedASDelay or 0.0
                local canSteadyFitNextCycle = (gcdRemainingAfterAutoShot + steadyCastDuration) < (nextRedPhaseDuration + allowedDelay)
                
                if canSteadyFitNextCycle then
                    -- Steady fits next cycle, so reset flag and cast Multi now
                    shouldCastMultiInsteadOfSteady = false
                    multiCastTime = now
                    currentRotaStep = ROTA_DO_NOTHING
                    -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
                    HamingwaysHunterTools_API.NotifyCast(cachedMultiName, 0.5)
                    CastSpellByName(cachedMultiName)
                else
                    -- Steady won't fit next cycle - set flag for next yellow decision
                    shouldCastMultiInsteadOfSteady = true
                    currentRotaStep = ROTA_DO_NOTHING
                    -- DebugRotaStepChange(currentRotaStep)  -- DISABLED
                end
                
                return
            end
        end
        
        return
    end
end

-- Protected wrapper for main rotation function (catches any errors to prevent crashes)
LazyHunt_DoRotation = function()
    local success, err = pcall(LazyHunt_DoRotation_Internal)
    if not success and err then
        -- Only print error once per session to avoid spam
        if not LazyHunt_ErrorShown then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000LazyHunt ERROR: " .. tostring(err) .. "|r")
            LazyHunt_ErrorShown = true
        end
    end
end

-- Event frame for interrupts and initialization
local frame = CreateFrame("Frame")
frame:RegisterEvent("SPELLCAST_INTERRUPTED")
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function()
    if event == "ADDON_LOADED" and arg1 == "LazyHunt" then
        -- Initialize saved variables
        LazyHuntDB = LazyHuntDB or {
            minimapPos = 225,
            allowedASDelay = 0.0,
        }
        
        -- CRITICAL: Reset ALL local state variables on reload
        currentStep = STEP_INIT
        currentRotaStep = ROTA_DO_NOTHING
        lastAutoShotTime = 0
        steadyCastTime = 0
        multiCastTime = 0
        shouldCastMultiInsteadOfSteady = false
        decisionMadeInYellow = false
        lastWeaponCacheTime = 0
        cachedWeaponSpeed = 2.0
        cachedAimingTime = 0.5
        cachedSteadyID = nil
        cachedSteadyName = nil
        cachedMultiID = nil
        cachedMultiName = nil
        cachedRapidFireID = nil
        
        -- Cache spell IDs for performance
        CacheSpellIDs()
        
        -- Mark addon as fully loaded and ready
        LazyHunt_IsLoaded = true
        
        -- Minimap button is created by LazyHunt_Minimap.lua
        
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt v" .. VERSION .. " geladen!|r")
    elseif event == "SPELLCAST_INTERRUPTED" then
        -- Reset cast timers and rotation step
        if steadyCastTime > 0 then
            steadyCastTime = 0
            currentRotaStep = ROTA_DO_NOTHING
            -- if debugMode then
            --     DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000Steady interrupted|r")
            -- end
        end
        if multiCastTime > 0 then
            multiCastTime = 0
            currentRotaStep = ROTA_DO_NOTHING
            -- if debugMode then
            --     DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000Multi interrupted|r")
            -- end
        end
    end
end)

-- ============================================================================
-- ========== TEMPORARY DEBUG FRAME (DISABLED - kann später reaktiviert werden) ===========
-- ============================================================================
--[[ DISABLED DEBUG FRAME CODE
local debugFrame = nil
local debugLogLines = {}
local MAX_DEBUG_LINES = 100
local debugScrollFrame = nil
local debugScrollChild = nil
local debugLogText = nil
local debugPhaseText = nil
local debugRotaText = nil
local debugUpdateInterval = 0.1
local lastDebugUpdate = 0
local lastTrackedPhase = nil
local lastTrackedCasting = false

-- Function to add message to debug log
local function AddDebugMessage(message)
    -- Disabled
    --[[
    if not debugFrame or not debugFrame:IsShown() then return end
    
    table.insert(debugLogLines, message)
    
    -- Keep only last 100 lines (Lua 5.0: use table.getn instead of #)
    while table.getn(debugLogLines) > MAX_DEBUG_LINES do
        table.remove(debugLogLines, 1)
    end
    
    -- Update display
    if debugLogText then
        debugLogText:SetText(table.concat(debugLogLines, "\n"))
    end
    
    -- Auto-scroll to bottom
    if debugScrollFrame then
        debugScrollFrame:UpdateScrollChildRect()
        local maxScroll = debugScrollChild:GetHeight() - debugScrollFrame:GetHeight()
        if maxScroll > 0 then
            debugScrollFrame:SetVerticalScroll(maxScroll)
        end
    end
    --]]
end

-- Override DebugRotaStepChange to also log to debug frame (only on change)
--[[
local originalDebugRotaStepChange = DebugRotaStepChange
function DebugRotaStepChange(newStep)
    -- Only call original and log if there's actually a change
    if newStep ~= lastRotaStep then
        originalDebugRotaStepChange(newStep)
        AddDebugMessage("|cFFFFFFFF[ROTA] " .. (lastRotaStep or "nil") .. " -> " .. newStep .. "|r")
    end
end
--]]

-- Create Debug Frame
local function CreateDebugFrame()
    -- Disabled
    --[[
    if debugFrame then return end
    
    -- Main frame
    debugFrame = CreateFrame("Frame", "LazyHuntDebugFrame", UIParent)
    debugFrame:SetWidth(400)
    debugFrame:SetHeight(500)
    debugFrame:SetPoint("CENTER", 0, 0)
    debugFrame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 }
    })
    debugFrame:SetMovable(true)
    debugFrame:EnableMouse(true)
    debugFrame:RegisterForDrag("LeftButton")
    debugFrame:SetScript("OnDragStart", function() this:StartMoving() end)
    debugFrame:SetScript("OnDragStop", function() this:StopMovingOrSizing() end)
    debugFrame:Hide()
    
    -- Title
    local title = debugFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -15)
    title:SetText("|cFF00FF00LazyHunt Debug|r")
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, debugFrame, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -5, -5)
    
    -- Clear Log button
    local clearBtn = CreateFrame("Button", nil, debugFrame, "UIPanelButtonTemplate")
    clearBtn:SetWidth(80)
    clearBtn:SetHeight(22)
    clearBtn:SetPoint("TOPRIGHT", -35, -5)
    clearBtn:SetText("Clear Log")
    clearBtn:SetScript("OnClick", function()
        debugLogLines = {}
        if debugLogText then
            debugLogText:SetText("")
        end
        AddDebugMessage("|cFF888888[Log cleared]|r")
    end)
    
    -- Phase display (Top section)
    local phaseLabel = debugFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    phaseLabel:SetPoint("TOPLEFT", 20, -45)
    phaseLabel:SetText("|cFFFFFFFFPhase:|r")
    
    debugPhaseText = debugFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    debugPhaseText:SetPoint("LEFT", phaseLabel, "RIGHT", 5, 0)
    debugPhaseText:SetText("---")
    
    -- Rotation step + IsCasting display
    local rotaLabel = debugFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    rotaLabel:SetPoint("TOPLEFT", 20, -70)
    rotaLabel:SetText("|cFFFFFFFFRotation:|r")
    
    debugRotaText = debugFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    debugRotaText:SetPoint("LEFT", rotaLabel, "RIGHT", 5, 0)
    debugRotaText:SetText("---")
    
    -- Separator
    local separator = debugFrame:CreateTexture(nil, "ARTWORK")
    separator:SetPoint("TOPLEFT", 15, -95)
    separator:SetPoint("TOPRIGHT", -15, -95)
    separator:SetHeight(1)
    separator:SetTexture(0.5, 0.5, 0.5, 1)
    
    -- Chat log label
    local logLabel = debugFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    logLabel:SetPoint("TOPLEFT", 20, -105)
    logLabel:SetText("|cFFFFFFFFRotation Log:|r")
    
    -- Scrollable frame for log
    debugScrollFrame = CreateFrame("ScrollFrame", "LazyHuntDebugScrollFrame", debugFrame, "UIPanelScrollFrameTemplate")
    debugScrollFrame:SetPoint("TOPLEFT", 15, -125)
    debugScrollFrame:SetPoint("BOTTOMRIGHT", -35, 15)
    
    debugScrollChild = CreateFrame("Frame", nil, debugScrollFrame)
    debugScrollChild:SetWidth(debugScrollFrame:GetWidth())
    debugScrollChild:SetHeight(1)
    debugScrollFrame:SetScrollChild(debugScrollChild)
    
    debugLogText = debugScrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    debugLogText:SetPoint("TOPLEFT", 5, 0)
    debugLogText:SetPoint("TOPRIGHT", -5, 0)
    debugLogText:SetJustifyH("LEFT")
    debugLogText:SetJustifyV("TOP")
    debugLogText:SetText("")
    
    -- Update function (only runs when frame is visible)
    debugFrame:SetScript("OnUpdate", function()
        if not this:IsShown() then return end
        
        local now = GetTime()
        if now - lastDebugUpdate < debugUpdateInterval then return end
        lastDebugUpdate = now
        
        -- Update phase display
        if HamingwaysHunterTools_API then
            local isRed = HamingwaysHunterTools_API.IsInRedPhase()
            local isYellow = HamingwaysHunterTools_API.IsInYellowPhase()
            local isShooting = HamingwaysHunterTools_API.IsShooting()
            
            -- Track phase changes and log them
            local currentPhase = nil
            if not isShooting then
                currentPhase = "NONE"
                debugPhaseText:SetText("|cFFAAAAAA[No Auto Shot]|r")
            elseif isRed then
                currentPhase = "RED"
                debugPhaseText:SetText("|cFFFF0000RED|r")
            elseif isYellow then
                currentPhase = "YELLOW"
                debugPhaseText:SetText("|cFFFFFF00YELLOW|r")
            else
                currentPhase = "UNKNOWN"
                debugPhaseText:SetText("|cFFAAAAAA[Unknown]|r")
            end
            
            -- Log phase changes
            if currentPhase ~= lastTrackedPhase then
                if currentPhase == "RED" then
                    AddDebugMessage("|cFFFF0000>>> Start RED Phase|r")
                elseif currentPhase == "YELLOW" then
                    AddDebugMessage("|cFFFFFF00>>> Start YELLOW Phase|r")
                end
                lastTrackedPhase = currentPhase
            end
            
            -- Update rotation step + casting status
            local isCasting = HamingwaysHunterTools_API.IsCasting()
            local castingText = isCasting and "|cFF00FFFF[CASTING]|r" or ""
            debugRotaText:SetText(currentRotaStep .. " " .. castingText)
            
            -- Track and log IsCasting changes
            if isCasting ~= lastTrackedCasting then
                if isCasting then
                    AddDebugMessage("|cFF00FF00[CAST] Started casting|r")
                else
                    AddDebugMessage("|cFF00FF00[CAST] Casting ended|r")
                end
                lastTrackedCasting = isCasting
            end
        else
            debugPhaseText:SetText("|cFFFF0000[HHT not loaded]|r")
            debugRotaText:SetText("---")
        end
    end)
    
    -- Add welcome message
    AddDebugMessage("|cFF00FF00LazyHunt Debug Frame initialized|r")
    AddDebugMessage("Rotation changes will appear here...")
    --]]
end

-- Slash command to toggle debug frame
local function ToggleDebugFrame()
    -- Disabled
    --[[
    if not debugFrame then
        CreateDebugFrame()
    end
    
    if debugFrame:IsShown() then
        debugFrame:Hide()
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt:|r Debug frame hidden")
    else
        debugFrame:Show()
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt:|r Debug frame shown")
    end
    --]]
    DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000LazyHunt:|r Debug frame is disabled")
end

-- ============================================================================
-- ========== END OF TEMPORARY DEBUG FRAME (DISABLED) =======================
-- ============================================================================
--]]

-- Slash commands
local function SlashCommandHandler(msg)
    msg = string.lower(msg or "")
    
    if msg == "help" or msg == "" then
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt|r v" .. VERSION)
        DEFAULT_CHAT_FRAME:AddMessage("Makro: |cFFFFFF00/script LazyHunt_DoRotation()|r")
        DEFAULT_CHAT_FRAME:AddMessage("Befehle: /lh debug, /lh status, /lh reset, /lh debugframe (oder df)")
    elseif msg == "debug" then
        debugMode = not debugMode
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt:|r Debug " .. (debugMode and "AN" or "AUS"))
    elseif msg == "reset" then
        steadyCastTime = 0
        multiCastTime = 0
        lastAutoShotTime = 0
        DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt:|r State reset")
    -- elseif msg == "debugframe" or msg == "df" then
    --     ToggleDebugFrame()
    elseif msg == "status" then
        if HamingwaysHunterTools_API then
            DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt Status:|r")
            DEFAULT_CHAT_FRAME:AddMessage("  Auto Shot: " .. tostring(HamingwaysHunterTools_API.IsShooting()))
            DEFAULT_CHAT_FRAME:AddMessage("  Red Phase: " .. tostring(HamingwaysHunterTools_API.IsInRedPhase()))
            DEFAULT_CHAT_FRAME:AddMessage("  Yellow Phase: " .. tostring(HamingwaysHunterTools_API.IsInYellowPhase()))
            DEFAULT_CHAT_FRAME:AddMessage("  Weapon Speed: " .. string.format("%.2f", HamingwaysHunterTools_API.GetWeaponSpeed()))
            DEFAULT_CHAT_FRAME:AddMessage("  steadyCastTime: " .. string.format("%.2f", steadyCastTime))
            DEFAULT_CHAT_FRAME:AddMessage("  multiCastTime: " .. string.format("%.2f", multiCastTime))
            DEFAULT_CHAT_FRAME:AddMessage("  lastAutoShotTime: " .. string.format("%.2f", lastAutoShotTime))
        else
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000LazyHunt: HamingwaysHunterTools not loaded!|r")
        end
    end
end

-- Register slash commands
SLASH_LAZYHUNT1 = "/lazyhunt"
SLASH_LAZYHUNT2 = "/lh"
SlashCmdList["LAZYHUNT"] = SlashCommandHandler

-- Startup message
DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00LazyHunt|r v" .. VERSION .. " loaded. Type /lh help")
