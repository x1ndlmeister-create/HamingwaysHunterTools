# Lua 5.0 Kompatibilität (WoW 1.12 Vanilla)

## WICHTIG: WoW 1.12 verwendet Lua 5.0, NICHT Lua 5.1+

## Verbotene Syntax / Features:

### 1. Length Operator
❌ `#table` oder `#string`
✅ `table.getn(table)` oder `string.len(str)`

### 2. Module System
❌ `module(...)`, `package.seeall`
✅ Direkte Variablen-Zuweisung

### 3. Varargs
❌ `...` (drei Punkte)
✅ `arg` table (implizit verfügbar)

### 4. for-in mit pairs/ipairs
❌ `for k, v in pairs(tbl) do`
✅ Manual iteration mit table.foreach oder while loops

### 5. String Patterns
❌ `%z` (null byte)
✅ Nur basic patterns

### 6. Math Functions
❌ `math.log10()`, einige moderne math Funktionen
✅ Nur die in Lua 5.0 verfügbaren

### 7. Table Functions
✅ `table.getn(t)` statt `#t`
✅ `table.setn(t, n)`
✅ `table.insert(t, value)`
✅ `table.remove(t, pos)`
✅ `table.foreach(t, func)`
✅ `table.foreachi(t, func)`

### 8. String Functions
✅ `string.len(s)` statt `#s`
✅ `string.format()`
✅ `string.find()`
✅ `string.sub()`

## Erlaubte Syntax:

- `local function name() end`
- `function table.method() end`
- `if/then/else/elseif/end`
- `for i=1,n do end`
- `while condition do end`
- `repeat until condition`
- Basic tables: `{key=value}` oder `{1,2,3}`

## Wichtige Unterschiede zu modernen Lua:

1. Keine metamethods wie `__len`
2. `table.getn()` und `table.setn()` existieren (in 5.1+ entfernt)
3. `arg` ist automatisch verfügbar in Funktionen mit varargs
4. `loadstring()` statt `load()`
5. `unpack()` ist global (nicht `table.unpack()`)
