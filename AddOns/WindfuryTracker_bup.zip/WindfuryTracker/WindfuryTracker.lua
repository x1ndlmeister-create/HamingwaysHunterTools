-- Windfury Tracker for Vanilla 1.12
-- Tracks which party members have Windfury Totem buff

local WFT = {}
WFT.frame = CreateFrame("Frame", "WindfuryTrackerFrame", UIParent)
WFT.playerFrames = {}
WFT.scanTooltip = CreateFrame("GameTooltip", "WFTScanTooltip", nil, "GameTooltipTemplate")
WFT.scanTooltip:SetOwner(WorldFrame, "ANCHOR_NONE")

-- Hauptfenster erstellen
local mainFrame = CreateFrame("Frame", "WFTMainFrame", UIParent)
mainFrame:SetWidth(200)
mainFrame:SetHeight(150)
mainFrame:SetPoint("CENTER", 0, 0)
mainFrame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 }
})
mainFrame:SetBackdropColor(0, 0, 0, 0.8)
mainFrame:EnableMouse(true)
mainFrame:SetMovable(true)
mainFrame:RegisterForDrag("LeftButton")
mainFrame:SetScript("OnDragStart", function() this:StartMoving() end)
mainFrame:SetScript("OnDragStop", function() this:StopMovingOrSizing() end)
mainFrame:Hide()

-- Title
local title = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("TOP", 0, -15)
title:SetText("Windfury Totem")

-- Close Button
local closeBtn = CreateFrame("Button", nil, mainFrame, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", -5, -5)

-- Player Status Frames
for i = 1, 5 do
    local pFrame = CreateFrame("Frame", nil, mainFrame)
    pFrame:SetWidth(180)
    pFrame:SetHeight(20)
    pFrame:SetPoint("TOPLEFT", 10, -30 - (i * 22))
    
    local nameText = pFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    nameText:SetPoint("LEFT", 5, 0)
    nameText:SetText("Empty")
    pFrame.nameText = nameText
    
    local statusIcon = pFrame:CreateTexture(nil, "OVERLAY")
    statusIcon:SetWidth(16)
    statusIcon:SetHeight(16)
    statusIcon:SetPoint("RIGHT", -5, 0)
    pFrame.statusIcon = statusIcon
    
    WFT.playerFrames[i] = pFrame
end

-- Funktion zum Scannen von Buffs mit Tooltip
function WFT:HasWindfuryBuff(unit)
    if not UnitExists(unit) then
        return false
    end
    
    local buffIndex = 1
    while UnitBuff(unit, buffIndex) do
        WFT.scanTooltip:ClearLines()
        WFT.scanTooltip:SetUnitBuff(unit, buffIndex)
        
        -- Tooltip Text auslesen
        local tooltipText = WFTScanTooltipTextLeft1:GetText()
        if tooltipText then
            -- Windfury Totem Buff erkennen
            if string.find(tooltipText, "Windfury") then
                return true
            end
        end
        
        buffIndex = buffIndex + 1
    end
    
    return false
end

-- Funktion zum Update der Anzeige
function WFT:UpdateDisplay()
    if not mainFrame:IsVisible() then
        return
    end
    
    for i = 1, 5 do
        local unit = (i == 1) and "player" or "party"..(i-1)
        local pFrame = WFT.playerFrames[i]
        
        if UnitExists(unit) then
            local name = UnitName(unit)
            local class = UnitClass(unit)
            local hasWF = WFT:HasWindfuryBuff(unit)
            
            -- Name und Klasse anzeigen
            pFrame.nameText:SetText(name.." ("..class..")")
            
            -- Status Icon setzen
            if hasWF then
                pFrame.statusIcon:SetTexture("Interface\\Icons\\Spell_Nature_Windfury")
                pFrame.statusIcon:SetVertexColor(0, 1, 0, 1) -- Grün
            else
                pFrame.statusIcon:SetTexture("Interface\\Icons\\Spell_ChargeNegative")
                pFrame.statusIcon:SetVertexColor(1, 0, 0, 0.5) -- Rot transparent
            end
            
            pFrame:Show()
        else
            pFrame:Hide()
        end
    end
end

-- Event Handler
WFT.frame:RegisterEvent("PLAYER_ENTERING_WORLD")
WFT.frame:RegisterEvent("PARTY_MEMBERS_CHANGED")
WFT.frame:RegisterEvent("PLAYER_AURAS_CHANGED")
WFT.frame:RegisterEvent("UNIT_AURA")

WFT.frame:SetScript("OnEvent", function()
    if event == "PLAYER_ENTERING_WORLD" then
        -- Initial setup
        WFT:UpdateDisplay()
    elseif event == "PARTY_MEMBERS_CHANGED" then
        WFT:UpdateDisplay()
    elseif event == "PLAYER_AURAS_CHANGED" or event == "UNIT_AURA" then
        WFT:UpdateDisplay()
    end
end)

-- Update Timer (Fallback für regelmäßige Updates)
local updateTimer = 0
WFT.frame:SetScript("OnUpdate", function()
    updateTimer = updateTimer + arg1
    if updateTimer >= 1 then -- Alle 1 Sekunde
        WFT:UpdateDisplay()
        updateTimer = 0
    end
end)

-- Slash Commands
SLASH_WINDFURYTRACKER1 = "/wft"
SLASH_WINDFURYTRACKER2 = "/windfury"
SlashCmdList["WINDFURYTRACKER"] = function(msg)
    if mainFrame:IsVisible() then
        mainFrame:Hide()
        DEFAULT_CHAT_FRAME:AddMessage("Windfury Tracker hidden")
    else
        mainFrame:Show()
        WFT:UpdateDisplay()
        DEFAULT_CHAT_FRAME:AddMessage("Windfury Tracker shown")
    end
end

-- Startup Message
DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00Windfury Tracker loaded! Use /wft or /windfury to toggle.|r")
